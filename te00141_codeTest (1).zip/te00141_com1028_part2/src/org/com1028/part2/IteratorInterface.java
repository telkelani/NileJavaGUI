package org.com1028.part2;
import java.util.Iterator;
public interface IteratorInterface {
	public Iterator create_iterator();

}
